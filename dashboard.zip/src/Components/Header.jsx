import React from 'react'
import "../Styles/Header.css"
const Header = () => {
  return (
    <div className='header'>
<div className='headerLinks'>
<h6> Login</h6>
<h6> Signup</h6>

</div>

    </div>
  )
}

export default Header